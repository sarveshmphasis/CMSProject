package com.java.cms;
import java.util.Date;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {
	Connection connection;
	PreparedStatement pst;
	
	public Order searchOrder(int orderId) throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Orders where orderId=?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, orderId);
		ResultSet rs = pst.executeQuery();
		Order order = null;
		if (rs.next()) {
			order = new Order();
			order.setorderId(rs.getInt("orderId"));
			order.setvendorId(rs.getInt("vendorId"));
			order.setcustomerId(rs.getInt("customerId"));
			order.setmenuId(rs.getInt("menuId"));
			order.setwalletId(rs.getInt("walletId"));
			order.setorderDate(rs.getDate("orderDate"));
			order.setquantityOrdered(rs.getInt("quantityOrdered"));
			order.setorderStatus(rs.getString("orderStatus"));
			order.setbillAmount(rs.getInt("billAmount"));
			order.setcomments(rs.getString("comments"));
		}
		return order;
	}
	
	public List<Order> showOrder() throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Orders";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Order> orderList = new ArrayList<Order>();
		Order order = null; 
		while(rs.next()) {
			order = new Order();
			order.setorderId(rs.getInt("orderId"));
			order.setvendorId(rs.getInt("vendorId"));
			order.setcustomerId(rs.getInt("customerId"));
			order.setmenuId(rs.getInt("menuId"));
			order.setwalletId(rs.getInt("walletId"));
			order.setorderDate(rs.getDate("orderDate"));
			order.setquantityOrdered(rs.getInt("quantityOrdered"));
			order.setorderStatus(rs.getString("orderStatus"));
			order.setbillAmount(rs.getInt("billAmount"));
			order.setcomments(rs.getString("comments"));
			orderList.add(order);
		}
		return orderList;
	}
	
	
	//--------------------------------------------------OrderPlace---------------------

	public String placeOrder(Order order) throws SQLException, ClassNotFoundException {
		int orderId = generateOrderId();
		order.setorderStatus("PENDING");
		java.util.Date today = new Date();
		java.sql.Date dbDate = new java.sql.Date(today.getTime());
		order.setorderDate(dbDate);
		Menu menu = new MenuDAO().searchMenu(order.getmenuId());
		int price = menu.getprice();
		int  billAmount = order.getquantityOrdered() * price; //int billAmount=quantityOrdered*price
		Wallet wallet = new WalletDAO().searchWallet(order.getwalletId());
		int Amount = wallet.getAmount();
		if (Amount - billAmount > 0) {
			order.setbillAmount(billAmount);
			order.setorderId(orderId);
			String cmd = "insert into Orders(orderId,vendorId,customerId,menuId,"
					+ "walletId,orderDate,quantityOrdered,orderStatus,billAmount,comments) "
					+ "values(?,?,?,?,?,?,?,?,?,?)";
			pst = connection.prepareStatement(cmd);
			pst.setInt(1, order.getorderId());
			pst.setInt(2, order.getvendorId());
			pst.setInt(3, order.getcustomerId());
			pst.setInt(4, order.getmenuId());
			pst.setInt(5, order.getwalletId());
			pst.setDate(6, (java.sql.Date) order.getorderDate());
			pst.setInt(7, order.getquantityOrdered());
			pst.setString(8, order.getorderStatus());
			pst.setInt(9, order.getbillAmount());
			pst.setString(10, order.getcomments());
			pst.executeUpdate();
			new WalletDAO().deductBalance(order.getwalletId(), billAmount);
			return "Order Placed Successfully...Wallet Balance Deducted...";
		}
		return "Insufficient Funds...";
		//order.setBillAmount(billAmount);
	}
	
	public int generateOrderId() throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select case when max(orderId) is NULL THEN 1"
				+ " else max(orderId)+1 end orderId from Orders";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		rs.next();
		int orderId = rs.getInt("orderId");
		return orderId;
	}
	//-------------------------------------------------------Pending Orders----
	public List<Order> showPendingOrder() throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Orders where orderStatus='pending'";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Order> orderList = new ArrayList<Order>();
		Order order = null; 
		while(rs.next()) {
			order = new Order();
			order.setorderId(rs.getInt("orderId"));
			order.setvendorId(rs.getInt("vendorId"));
			order.setcustomerId(rs.getInt("customerId"));
			order.setmenuId(rs.getInt("menuId"));
			order.setwalletId(rs.getInt("walletId"));
			order.setorderDate(rs.getDate("orderDate"));
			order.setquantityOrdered(rs.getInt("quantityOrdered"));
			order.setorderStatus(rs.getString("orderStatus"));
			order.setbillAmount(rs.getInt("billAmount"));
			order.setcomments(rs.getString("comments"));
			orderList.add(order);
		}
		return orderList;
	}
	
	//-----------------------Accept/RejectOrder-----------------------
	public String acceptOrRejectOrder(int orderId, int vendorId, String status) throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		Order order = searchOrder(orderId);
		if (order.getvendorId()==vendorId) {
			if (status.toUpperCase().equals("accepted")) {
				String cmd = "Update Orders set orderStatus='ACCEPTED' "
						+ " WHERE orderId=?";
				pst = connection.prepareStatement(cmd);
				pst.setInt(1, orderId);
				pst.executeUpdate();
				return "Order Approved Successfully...";
			} else {
				String cmd = "Update Orders set orderStatus='REJECTED' "
						+ " WHERE orderId=?";
				pst = connection.prepareStatement(cmd);
				pst.setInt(1, orderId);
				pst.executeUpdate();
				cmd = "Update Wallet set Amount=Amount+? where walletId=?";
				pst = connection.prepareStatement(cmd);
				pst.setInt(1, order.getbillAmount());
				pst.setInt(2, order.getwalletId());
				pst.executeUpdate();
				return "Order Rejected Amount Refunded...";
			}
		} 
		return "You are unauthorized vendor...";
	}
}
