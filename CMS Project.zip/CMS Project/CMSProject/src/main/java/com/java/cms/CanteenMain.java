package com.java.cms;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class CanteenMain {

	static Scanner sc =  new Scanner(System.in);
	
	public static void main(String[] args) {
		int choice;
		do {
			System.out.println("O P T I O N S");
			System.out.println("---------------");
			System.out.println("1. ADD Restaurant");
			System.out.println("2. Show Restaurant ");
			System.out.println("3. Search Restaurant");
			System.out.println("4. add menu ");
			System.out.println("5. Show menu ");
			System.out.println("6. search menu ");
			System.out.println("7. add Customer ");
			System.out.println("8. show Customer ");
			System.out.println("9. search Customer ");
			System.out.println("10. Add Vendor ");
			System.out.println("11. show Vendor ");
			System.out.println("12. search Vendor ");
			System.out.println("13. Place order ");
			System.out.println("14. show order ");
			System.out.println("15. search order ");
			System.out.println("16. show Wallet ");//  make one  search wallet by customer Id
			System.out.println("17. search Wallet ");
			System.out.println("18. Accept Or Reject Order");
			System.out.println("19. Pending  orders ");//Customers pending orders,restaurent pending orders
			System.out.println("Enter Your Choice   ");       //SELECT * FROM orders WHERE orderStatus='PENDING';
			choice = sc.nextInt();
			switch(choice) {
			case 1 : 
				addRestaurent();
			break;
			case 2 : 
				RestaurentShow();
			break;
			case 3 : 
				try {
					RestaurentSearch();
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4 : 
				addMenu();
			break;
			case 5 : 
				MenuShow();
			break;
			case 6 : 
				MenuSearch();
			break;
			case 7 : 
				addCustomer();
			break;
			case 8 : 
				CustomerShow();
			break;
			case 9 : 
				CustomerSearch();
			break;
			case 10 : 
				addVendor();
			break;
			case 11 : 
				VendorShow();
			break;
			case 12 : 
				VendorSearch();
			break;
			case 13 : 
				try {
					placeOrder();
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			break;
			case 14 : 
				OrderShow();
			break;
			case 15 : 
				OrderSearch();
			break;
			case 16 : 
				WalletShow();
			break;
			case 17 : 
				WalletSearch();
			break;
			case 18 : 
				try {
					acceptOrReject();
				} catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				}
				break;
			case 19 : 
				ShowPendingOrder();
			break;
			case 20 : 
				return;
			}
		} while(choice!=20);
	}
	
	
	public static void ShowPendingOrder() {
		OrderDAO dao = new OrderDAO();
		try {
			List<Order> orderList = dao.showPendingOrder();
			for (Order order : orderList) {
				System.out.println(order);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}


	private static void acceptOrReject() throws ClassNotFoundException, SQLException {
		int vendorId;
		int orderId;
		String orderStatus;
		System.out.println("Enter Vendor Id   ");
		vendorId = sc.nextInt();
		System.out.println("Enter Order Id   ");
		orderId = sc.nextInt();
		System.out.println("Enter orderStatus   ");
		orderStatus =sc.next();
		System.out.println(new OrderDAO().acceptOrRejectOrder(orderId, vendorId, orderStatus));
		// TODO Auto-generated method stub
		
	}


	//-----------------------------------------------------------
	
	private static void placeOrder() throws ClassNotFoundException, SQLException {
		Order order = new Order();
		System.out.println("Enter Customer Id   ");
		order.setcustomerId(sc.nextInt());
		System.out.println("Enter Vendor Id  ");
		order.setvendorId(sc.nextInt());
		System.out.println("Enter Menu Id  ");
		order.setmenuId(sc.nextInt());
		System.out.println("Enter Wallet Id  ");
		order.setwalletId(sc.nextInt());
		System.out.println("Enter Quantity Ordered  ");
		order.setquantityOrdered(sc.nextInt());
		System.out.println("Enter Comments  ");
		order.setcomments(sc.next());
		OrderDAO dao = new OrderDAO();
		System.out.println(dao.placeOrder(order));
		// TODO Auto-generated method stub
		
	}
	private static void addVendor() {
		Scanner sc = new Scanner(System.in);
		Vendor vendor = new Vendor();
		System.out.println("Enter vendorName   ");
		vendor.setvendorName(sc.next());
		System.out.println("Enter vendorState  ");
		vendor.setvendorState(sc.next());
		System.out.println("Enter vendorCity   ");
		vendor.setvendorCity(sc.next());
		System.out.println("Enter vendorEmail   ");
		vendor.setvendorEmail(sc.next());
		System.out.println("Enter vendorMob   ");
		vendor.setvendorMob(sc.next());
		VendorDAO dao = new VendorDAO();
		try {
			System.out.println(dao.addVendor(vendor));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}
	public static void addCustomer() {
		
		Scanner sc = new Scanner(System.in);
		Customer customer = new Customer();
		System.out.println("Enter customername   ");
		customer.setcustomername(sc.next());
		System.out.println("Enter customerState  ");
		customer.setcustomerState(sc.next());
		System.out.println("Enter customerCity   ");
		customer.setcustomerCity(sc.next());
		System.out.println("Enter customerEmail   ");
		customer.setcustomerEmail(sc.next());
		System.out.println("Enter customerMob   ");
		customer.setcustomerMob(sc.next());
		CustomerDAO dao = new CustomerDAO();
		try {
			System.out.println(dao.addCustomer(customer));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		// TODO Auto-generated method stub
	public static void addMenu() {
			Scanner sc = new Scanner(System.in);
			Menu menu = new Menu();
			System.out.println("Enter restaurentId  ");
			menu.setrestaurentId(sc.nextInt());
			System.out.println("Enter ItemName  ");
			menu.setItemName(sc.next());
			System.out.println("Enter menuType   ");
			menu.setmenuType(sc.next());
			System.out.println("Enter price   ");
			menu.setprice(sc.nextInt());
			MenuDAO dao = new MenuDAO();
			try {
				System.out.println(dao.addMenu(menu));
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// TODO Auto-generated method stub
	public static void addRestaurent() {
			Scanner sc = new Scanner(System.in);
			Restaurent restaurent = new Restaurent();
			System.out.println("Enter restaurentName   ");
			restaurent.setrestaurentName(sc.next());
			System.out.println("Enter restaurentCity  ");
			restaurent.setrestaurentCity(sc.next());
			System.out.println("Enter restaurentBranch   ");
			restaurent.setrestaurentBranch(sc.next());
			System.out.println("Enter restaurentEmail   ");
			restaurent.setrestaurentEmail(sc.next());
			System.out.println("Enter restaurentContactNo   ");
			restaurent.setrestaurentContactNo(sc.next());
			RestaurentDAO dao = new RestaurentDAO();
			try {
				System.out.println(dao.addRestaurent(restaurent));
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		// TODO Auto-generated method stub
	private static void OrderSearch() {
			int orderId;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter OrderId=    ");
			orderId = sc.nextInt();
			OrderDAO dao = new OrderDAO();
			try {
				Order order = dao.searchOrder(orderId);
				if (order!=null) {
					System.out.println(order);
				} else {
					System.out.println("*** Record Not Found ***");
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// TODO Auto-generated method stub
	private static void OrderShow() {
			OrderDAO dao = new OrderDAO();
			try {
				List<Order> orderList = dao.showOrder();
				for (Order order : orderList) {
					System.out.println(order);
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// TODO Auto-generated method stub
	private static void WalletShow() {
			WalletDAO dao = new WalletDAO();
			try {
				List<Wallet> walletList = dao.showWallet();
				for (Wallet wallet : walletList) {
					System.out.println(wallet);
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// TODO Auto-generated method stub
	public static void WalletSearch() {
			int walletId;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Wallet Id    ");
			walletId = sc.nextInt();
			WalletDAO dao = new WalletDAO();
			try {
				Wallet wallet = dao.searchWallet(walletId);
				if (wallet!=null) {
					System.out.println(wallet);
				} else {
					System.out.println("*** Record Not Found ***");
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// TODO Auto-generated method stub
	private static void VendorSearch() {
			int vendorId;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter VendorID=    ");
			vendorId = sc.nextInt();
			VendorDAO dao = new VendorDAO();
			try {
				Vendor vendor = dao.searchVendor(vendorId);
				if (vendor!=null) {
					System.out.println(vendor);
				} else {
					System.out.println("*** Record Not Found ***");
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// TODO Auto-generated method stub
	private static void VendorShow() {
			VendorDAO dao = new VendorDAO();
			try {
				List<Vendor> vendorList = dao.showVendor();
				for (Vendor vendor : vendorList) {
					System.out.println(vendor);
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// TODO Auto-generated method stub
	private static void CustomerSearch() {
			int customerId;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter CustomerID=    ");
			customerId = sc.nextInt();
			CustomerDAO dao = new CustomerDAO();
			try {
				Customer customer = dao.searchCustomer(customerId);
				if (customer!=null) {
					System.out.println(customer);
				} else {
					System.out.println("*** Record Not Found ***");
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// TODO Auto-generated method stub
	public static void CustomerShow() {
			CustomerDAO dao = new CustomerDAO();
			try {
				List<Customer> customerList = dao.showCustomer();
				for (Customer customer : customerList) {
					System.out.println(customer);
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// TODO Auto-generated method stub
	public static void MenuShow() {
			MenuDAO dao = new MenuDAO();
			try {
				List<Menu> menuList = dao.showMenu();
				for (Menu menu : menuList) {
					System.out.println(menu);
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		// TODO Auto-generated method stub
	public static void RestaurentSearch() throws ClassNotFoundException, SQLException {
			int restaurentId;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Restaurent    ");
			restaurentId = sc.nextInt();
			RestaurentDAO dao = new RestaurentDAO();
			try {
				Restaurent restaurent = dao.searchRestaurent(restaurentId);
				if (restaurent!=null) {
					System.out.println(restaurent);
				} else {
					System.out.println("*** Record Not Found ***");
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	public static void RestaurentShow() {
			RestaurentDAO dao = new RestaurentDAO();
			try {
				List<Restaurent> restaurentList = dao.showRestaurent();
				for (Restaurent restaurent : restaurentList) {
					System.out.println(restaurent);
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
	}
	public static void MenuSearch() {
			int menuId;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Menu Id=    ");
			menuId = sc.nextInt();
			MenuDAO dao = new MenuDAO();
			try {
				Menu menu = dao.searchMenu(menuId);
				if (menu!=null) {
					System.out.println(menu);
				} else {
					System.out.println("*** Record Not Found ***");
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
